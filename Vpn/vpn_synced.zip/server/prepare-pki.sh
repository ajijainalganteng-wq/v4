#!/bin/bash
set -euo pipefail
cd /etc/openvpn/server

need_new=0

if [ ! -s ca.crt ] || [ ! -s server.crt ] || [ ! -s server.key ]; then
    need_new=1
elif ! openssl x509 -in server.crt -checkend 86400 -noout >/dev/null 2>&1; then
    need_new=1
elif ! openssl verify -CAfile ca.crt server.crt >/dev/null 2>&1; then
    need_new=1
else
    cert_pub=$(openssl x509 -in server.crt -pubkey -noout 2>/dev/null | openssl pkey -pubin -outform DER 2>/dev/null | sha256sum | awk '{print $1}')
    key_pub=$(openssl pkey -in server.key -pubout -outform DER 2>/dev/null | sha256sum | awk '{print $1}')
    [ -n "$cert_pub" ] && [ "$cert_pub" = "$key_pub" ] || need_new=1
fi

if [ "$need_new" -eq 0 ]; then
    echo "Sertifikat dan private key OpenVPN masih valid."
    exit 0
fi

STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="/etc/openvpn/backup-pki-$STAMP"
mkdir -p "$BACKUP"

for f in ca.crt ca.key server.crt server.key server.csr ca.srl; do
    [ ! -e "$f" ] || cp -a "$f" "$BACKUP/"
done

umask 077

echo "Membuat CA dan sertifikat server baru..."

openssl req -x509 -newkey rsa:3072 -sha256 -nodes \
    -keyout ca.key -out ca.crt -days 3650 \
    -subj "/CN=RIPZZ-OPENVPN-CA"

openssl req -new -newkey rsa:3072 -nodes \
    -keyout server.key -out server.csr \
    -subj "/CN=server"

cat > server-ext.cnf <<'EOF'
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=DNS:server
EOF

openssl x509 -req -in server.csr \
    -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out server.crt -days 825 -sha256 \
    -extfile server-ext.cnf

rm -f server.csr server-ext.cnf ca.srl

chmod 600 ca.key server.key
chmod 644 ca.crt server.crt

openssl verify -CAfile ca.crt server.crt

echo "CA dan sertifikat server baru berhasil dibuat."
echo "Konfigurasi client harus dibuat ulang agar menggunakan CA baru."
