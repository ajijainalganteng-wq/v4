#!/bin/bash
# Warna
grenbo="\e[92;1m"
NC='\e[0m'

# Function to show a progress bar

fun_bar() {
    local STATUS="$HOME/fim"
    rm -f "$STATUS"

    (
        "$1" >/dev/null 2>&1
        echo $? > "$STATUS"
    ) &

    local PID=$!

    tput civis 2>/dev/null
    echo -ne "  \033[0;33mPlease Wait Loading \033[1;37m- \033[0;33m["

    while kill -0 "$PID" 2>/dev/null; do
        echo -ne "\033[0;32m#"
        sleep 0.2
    done

    wait "$PID"
    local RESULT=$(cat "$STATUS" 2>/dev/null)
    rm -f "$STATUS"

    if [ "$RESULT" = "0" ]; then
        echo -e "\033[0;33m]\033[1;37m -\033[1;32m OK !\033[1;37m"
    else
        echo -e "\033[0;33m]\033[1;37m -\033[1;31m FAILED !\033[1;37m"
        tput cnorm 2>/dev/null
        return 1
    fi

    tput cnorm 2>/dev/null
}
# Function to update and install required packages

update_install() {
    cd /root >/dev/null 2>&1

    apt-get update -y
    apt-get install -y \
        wget curl ca-certificates \
        neofetch git \
        python3 python3-pip python3-venv \
        build-essential

    # Install 7-Zip sesuai paket yang tersedia
    if apt-cache show 7zip >/dev/null 2>&1; then
        apt-get install -y 7zip
    else
        apt-get install -y p7zip-full
    fi
}
# Membersihkan instalasi lama


# Function to download and set up the bot

setup_bot() {
    local PASS="HeyHeyMauDecryptYaAwokawokARISTORE"

    cd /root || return 1

    # Bersihkan file unduhan lama
    rm -f bot.zip /usr/bin/kyt.zip

    # Download file bot
    wget -q --timeout=30 --tries=3 \
        "https://raw.githubusercontent.com/ajijainalganteng-wq/v4/main/Bot/bot.zip" \
        -O bot.zip || {
        echo "Gagal mengunduh bot.zip"
        return 1
    }

    # Download file kyt
    wget -q --timeout=30 --tries=3 \
        "https://raw.githubusercontent.com/ajijainalganteng-wq/v4/main/Bot/kyt.zip" \
        -O /usr/bin/kyt.zip || {
        echo "Gagal mengunduh kyt.zip"
        return 1
    }

    # Periksa ukuran file
    [ -s bot.zip ] && [ -s /usr/bin/kyt.zip ] || {
        echo "File ZIP kosong atau tidak lengkap"
        return 1
    }

    # Tentukan perintah 7-Zip
    if command -v 7z >/dev/null 2>&1; then
        ZIP="7z"
    elif command -v 7zz >/dev/null 2>&1; then
        ZIP="7zz"
    else
        echo "7-Zip belum terpasang"
        return 1
    fi

    # Validasi arsip
    "$ZIP" t "-p$PASS" bot.zip >/dev/null 2>&1 || {
        echo "Arsip bot.zip rusak atau password salah"
        return 1
    }

    "$ZIP" t "-p$PASS" /usr/bin/kyt.zip >/dev/null 2>&1 || {
        echo "Arsip kyt.zip rusak atau password salah"
        return 1
    }

    # Ekstrak bot
    rm -rf /usr/bin/Bot /root/bot

    "$ZIP" x -y "-p$PASS" bot.zip >/dev/null 2>&1 || return 1

    [ -d /root/bot ] || {
        echo "Folder bot tidak ditemukan setelah ekstraksi"
        return 1
    }

    mkdir -p /usr/bin/Bot
    mv /root/bot/* /usr/bin/Bot/ || return 1
    chmod -R +x /usr/bin/Bot/

    rm -rf /root/bot /root/bot.zip

    # Ekstrak KYT
    rm -rf /usr/bin/kyt
    cd /usr/bin || return 1

    "$ZIP" x -y "-p$PASS" kyt.zip >/dev/null 2>&1 || return 1

    [ -f /usr/bin/kyt/requirements.txt ] || {
        echo "requirements.txt tidak ditemukan"
        return 1
    }

    # Instal Python menggunakan virtual environment
    cd /usr/bin/kyt || return 1

    python3 -m venv venv || return 1

    ./venv/bin/python -m pip install --upgrade pip || return 1

    ./venv/bin/pip install -r requirements.txt || return 1


    # Persiapkan Systemd service (belum menjalankan bot)
    mkdir -p /etc/systemd/system

    cat > /etc/systemd/system/kyt.service << 'END'
[Unit]
Description=RIPZZ STORE Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/usr/bin
ExecStart=/usr/bin/kyt/venv/bin/python -m kyt
Restart=always
RestartSec=5
StartLimitIntervalSec=0

[Install]
WantedBy=multi-user.target
END

    # Reload konfigurasi Systemd
    systemctl daemon-reload || return 1

    # Pastikan bot tidak berjalan setelah instalasi
    systemctl disable kyt >/dev/null 2>&1
    systemctl stop kyt >/dev/null 2>&1
    systemctl reset-failed kyt >/dev/null 2>&1

    rm -f /usr/bin/kyt.zip

    echo "Instalasi bot berhasil"
    echo "Service kyt sudah disiapkan dalam kondisi OFF"
    return 0

    echo "Instalasi bot berhasil"
}


# Main script

# Clear the terminal
clear

# Update and install required packages with progress bar
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[1;97;101m        UPDATE & INSTALL PACKAGES         \e[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
fun_bar 'update_install'

 #Menjalankan instalasi bot dengan progress bar
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[1;97;101m          BOT SETUP IN PROGRESS           \e[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
fun_bar 'setup_bot'
# Display completion message
cd /root
rm -rf kyt.sh
echo -e "\033[1;32mInstallation complete!\033[0m"
read -n 1 -s -r -p " Press Enter for Back to Manage"
bash /usr/bin/m-bot
