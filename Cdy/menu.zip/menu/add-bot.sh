#!/bin/bash

# Mendapatkan nilai NS dan domain
NS=$(cat /etc/xray/dns) >/dev/null 2>&1
domain=$(cat /etc/xray/domain) >/dev/null 2>&1

# Warna
grenbo="\e[92;1m"
NC='\e[0m'

# Menghentikan service kyt dan menghapus session file
cd /etc/systemd/system/ >/dev/null 2>&1
rm -rf kyt.service >/dev/null 2>&1
systemctl stop kyt  >/dev/null 2>&1
mkdir -p /usr/bin/kyt
rm -rf /usr/bin/kyt/var.txt
rm -rf /usr/bin/kyt/database.db
find /usr/bin/ -name "*.session*" -delete

# Membersihkan layar
clear

# Menampilkan banner
echo ""
figlet "RIPZZ BOT SYSTEM" | lolcat

# Menampilkan informasi dan panduan bot
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[1;97;101m              ADD BOT PANEL               \e[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "${grenbo}Tutorial Buat Bot Dan Mendapatkan ID Telegram"
echo -e "${grenbo}[*] Buat Bot Atau Dapatkan Token Bot: @BotFather"
echo -e "${grenbo}[*] Cara Cek ID Telegram: @MissRose_bot , perintah /info"
echo -e "${grenbo}[*] Cara Menggunakan Bot Multi ID Telegram ☞ 987654321,123456789"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\033[1;36mExample Input:\033[0m"
echo -e "${grenbo}[*] Bot Token: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11\033[0m"
echo -e "${grenbo}[*] Admin Telegram IDs: 987654321,123456789\033[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"

# Input token dan ID Telegram dari pengguna
read -e -p "[*] Input your Bot Token : " bottoken
read -e -p "[*] Input Your Telegram ID : " admin

# Input token dan ID Telegram
read -e -p "[*] Input your Bot Token : " bottoken
read -e -p "[*] Input Your Telegram ID : " admin

# Validasi input
if [[ -z "$bottoken" || -z "$admin" ]]; then
    echo "Token dan Telegram ID tidak boleh kosong!"
    exit 1
fi

# Simpan konfigurasi bot
cat > /usr/bin/kyt/var.txt <<EOF
BOT_TOKEN='$bottoken'
ADMIN='$admin'
DOMAIN='$domain'
PUB='$PUB'
HOST='$NS'
EOF

# Simpan database konfigurasi
echo -e "#bot# $bottoken $admin" > /etc/bot/.bot.db

# Lindungi konfigurasi
chmod 600 /usr/bin/kyt/var.txt
chmod 600 /etc/bot/.bot.db

# Membersihkan layar
clear



# ==========================================
# SYSTEMD KYT - START BOT
# ==========================================

echo "Preparing KYT service..."

# Pastikan file service tersedia
if [ ! -f /etc/systemd/system/kyt.service ]; then
    echo "Service file tidak ditemukan!"
    exit 1
fi

# Pastikan Python dan modul bot tersedia
if [ ! -x /usr/bin/kyt/venv/bin/python ]; then
    echo "Python virtual environment tidak ditemukan!"
    exit 1
fi

if [ ! -s /usr/bin/kyt/var.txt ]; then
    echo "Konfigurasi bot tidak ditemukan!"
    exit 1
fi

# Reload konfigurasi Systemd
systemctl daemon-reload || exit 1

# Bersihkan status gagal sebelumnya
systemctl reset-failed kyt >/dev/null 2>&1

# Aktifkan service agar berjalan otomatis setelah reboot
systemctl enable kyt || exit 1

# Jalankan bot
systemctl restart kyt || exit 1

# Tunggu hingga service benar-benar aktif
BOT_ACTIVE=0

for i in {1..15}; do
    if systemctl is-active --quiet kyt; then
        BOT_ACTIVE=1
        break
    fi
    sleep 1
done

# Periksa hasil
if [ "$BOT_ACTIVE" -eq 1 ]; then
    echo ""
    echo "=================================="
    echo "       RIPZZ STORE BOT ON"
    echo "=================================="
    echo "Service Status : ACTIVE"
    echo "Auto Start     : ENABLED"
    echo "Reboot Support : ENABLED"
    echo "=================================="
else
    echo ""
    echo "=================================="
    echo "       BOT START FAILED"
    echo "=================================="

    systemctl status kyt --no-pager -l
    echo ""
    echo "===== BOT ERROR LOG ====="
    journalctl -u kyt -n 40 --no-pager

    exit 1
fi


# Kembali ke direktori root dan hapus file kyt.sh
cd /root

# Menampilkan data bot
clear
echo "Done"
echo "Your Data Bot"
echo -e "==============================="
echo "Token Bot     : $bottoken"
echo "Admin         : $admin"
echo "Domain        : $domain"
echo -e "==============================="
echo "Installations complete, type /menu on your bot"
read -n 1 -s -r -p " Press Enter for Back to Manage"
bash /usr/bin/m-bot
