#!/bin/bash

# Mendapatkan nilai NS dan domain
NS=$(cat /etc/xray/dns 2>/dev/null)
domain=$(cat /etc/xray/domain 2>/dev/null)

# Warna
grenbo="\e[92;1m"
NC='\e[0m'

# ==========================================
# PERSIAPAN ADD BOT
# ==========================================

# Pastikan direktori tersedia
mkdir -p /usr/bin/kyt
mkdir -p /etc/bot

# Pastikan service hasil install-bot tersedia
if [ ! -f /etc/systemd/system/kyt.service ]; then
    echo "Service kyt tidak ditemukan!"
    echo "Silakan jalankan install-bot terlebih dahulu."
    exit 1
fi

# Hentikan bot sementara untuk memperbarui konfigurasi
systemctl stop kyt >/dev/null 2>&1

# Membersihkan layar
clear

# Menampilkan banner
echo ""
figlet "RIPZZ BOT SYSTEM" | lolcat

# Menampilkan informasi dan panduan bot
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[1;97;101m              ADD BOT PANEL               \e[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "${grenbo}Tutorial Buat Bot Dan Mendapatkan ID Telegram"
echo -e "${grenbo}[*] Buat Bot Atau Dapatkan Token Bot: @BotFather"
echo -e "${grenbo}[*] Cara Cek ID Telegram: @MissRose_bot , perintah /info"
echo -e "${grenbo}[*] Cara Menggunakan Bot Multi ID Telegram ☞ 987654321,123456789"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\033[1;36mExample Input:\033[0m"
echo -e "${grenbo}[*] Bot Token: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11\033[0m"
echo -e "${grenbo}[*] Admin Telegram IDs: 987654321,123456789\033[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"

# ==========================================
# INPUT TOKEN DAN ID TELEGRAM
# ==========================================

read -e -p "[*] Input your Bot Token : " bottoken
read -e -p "[*] Input Your Telegram ID : " admin

# Validasi input
if [[ -z "$bottoken" || -z "$admin" ]]; then
    echo "Token dan Telegram ID tidak boleh kosong!"
    exit 1
fi

# ==========================================
# SIMPAN KONFIGURASI BOT
# ==========================================

cat > /usr/bin/kyt/var.txt <<EOF
BOT_TOKEN='$bottoken'
ADMIN='$admin'
DOMAIN='$domain'
PUB='$PUB'
HOST='$NS'
EOF

# Simpan database konfigurasi
echo -e "#bot# $bottoken $admin" > /etc/bot/.bot.db

# Lindungi konfigurasi
chmod 600 /usr/bin/kyt/var.txt
chmod 600 /etc/bot/.bot.db

# ==========================================
# VALIDASI FILE BOT
# ==========================================

if [ ! -x /usr/bin/kyt/venv/bin/python ]; then
    echo "Python virtual environment tidak ditemukan!"
    exit 1
fi

if [ ! -f /usr/bin/kyt/requirements.txt ]; then
    echo "File requirements.txt tidak ditemukan!"
    exit 1
fi

if [ ! -s /usr/bin/kyt/var.txt ]; then
    echo "Konfigurasi bot gagal disimpan!"
    exit 1
fi

if [ ! -f /etc/systemd/system/kyt.service ]; then
    echo "File service kyt tidak ditemukan!"
    exit 1
fi

# ==========================================
# SYSTEMD KYT - START BOT
# ==========================================

echo ""
echo "Preparing KYT service..."

# Reload konfigurasi Systemd
systemctl daemon-reload || exit 1

# Bersihkan status gagal sebelumnya
systemctl reset-failed kyt >/dev/null 2>&1

# Aktifkan service agar berjalan otomatis setelah reboot
systemctl enable kyt || {
    echo "Gagal mengaktifkan auto-start service!"
    exit 1
}

# Jalankan bot
systemctl restart kyt || {
    echo "Gagal menjalankan service kyt!"
    exit 1
}

# ==========================================
# VERIFIKASI STATUS BOT
# ==========================================

BOT_ACTIVE=0

for i in {1..15}; do
    if systemctl is-active --quiet kyt; then
        BOT_ACTIVE=1
        break
    fi

    sleep 1
done

# ==========================================
# HASIL PENGAKTIFAN BOT
# ==========================================

if [ "$BOT_ACTIVE" -eq 1 ]; then

    echo ""
    echo "=================================="
    echo "       RIPZZ STORE BOT ON"
    echo "=================================="
    echo "Service Status : ACTIVE"
    echo "Auto Start     : ENABLED"
    echo "Reboot Support : ENABLED"
    echo "=================================="

else

    echo ""
    echo "=================================="
    echo "       BOT START FAILED"
    echo "=================================="

    echo ""
    echo "===== SERVICE STATUS ====="
    systemctl status kyt --no-pager -l

    echo ""
    echo "===== BOT ERROR LOG ====="
    journalctl -u kyt -n 40 --no-pager

    exit 1
fi

# ==========================================
# SELESAI
# ==========================================

cd /root || exit 1

clear

echo "Done"
echo "Your Data Bot"
echo -e "==============================="
echo "Token Bot     : $bottoken"
echo "Admin         : $admin"
echo "Domain        : $domain"
echo -e "==============================="
echo "Service Status : ON"
echo "Auto Start     : ENABLED"
echo "==============================="
echo "Installations complete, type /menu on your bot"

read -n 1 -s -r -p " Press Enter for Back to Manage"

bash /usr/bin/m-bot
